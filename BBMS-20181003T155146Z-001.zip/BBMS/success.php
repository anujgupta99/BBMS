<?php
echo 'You have successfully registered!;


?>